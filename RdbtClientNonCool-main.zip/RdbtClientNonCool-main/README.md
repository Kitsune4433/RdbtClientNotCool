# Support @ https://discord.gg/NA9xF4uVa9

# Rdbt Client V4

This free and open-source mining macro can help you automate tasks on hypixel skyblock.
This client is almost entirely AI generated, and yet it still can outpreform the competition.

Contributions are always welcome! Remember to star the repo at the top of the page.

## Features

- Gemstone Macro
- Ore Macro
- Scatha Macro (Requires a custom scatha-pro mod, cause I cba fixing it, which is included in the download)
- Commission Macro
- Advanced Failsafes
- Automated Response Bot

## Installation

Install [Chattriggers](https://chattriggers.com/#download) and launch. 

Inside minecraft run the command /ct files and open the modules folder.

Download the latest [Rdbt Client](https://github.com/rdbtCVS/rdbtclient/archive/refs/heads/main.zip) and unzip it in the folder.

Ensure the new folder is called "RdbtClient".

Run the command /ct reload.

You can open the GUI with /rdbt

Macro keybinds are set inside the vanilla keybinds settings in minecraft. 

## Showcase

Scatha:

https://github.com/user-attachments/assets/0ee78a77-73bb-4bb8-8a45-67a050796ca4

Gemstone:

https://github.com/user-attachments/assets/2d7656f2-0374-42be-8508-fceed08e6472

Anti-Staff:

https://github.com/user-attachments/assets/3b428444-90a0-424c-bfa7-c295fee93c2e

## Scatha Usage

Start the macro at X832, Z380+. It should do the rest.

HOTM: Max mining speed, Max mining spread, anomalous desires, and the +30mf

Items:
- Aspect of the end/void
- Daed Axe
- Rod
- Drill

Armor (Wardrobe):
- (Glossy) Mineral Armor 
- Sorrow or Superior Armor

Pet Rules:

On rod -> Swap to black cat (magic find)

On gemstone collection -> Swap to bal (heat res)

## Contributing

Contributions are always welcome!

See `contributing.md` for ways to get started.

Please adhere to this project's `code of conduct`.


## License

[Unlicense](https://choosealicense.com/licenses/unlicense/)

